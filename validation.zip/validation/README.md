# jquery-validation
Automate validation form with jQuery with simple step 
